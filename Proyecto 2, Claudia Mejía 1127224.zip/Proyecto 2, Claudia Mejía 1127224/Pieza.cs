﻿namespace Proyecto_2__Claudia_Mejía_1127224;

public class Pieza
{
    public int TipoPieza; // Almacena el tipo de pieza
    public int ColorPieza; // Almacena el color de la pieza
    public int CantidadPiezas; // Almacena la cantidad de piezas
    public string PosicionPieza = ""; // Almacena la posición de la pieza

    // Método para agregar piezas al tablero
    public string AgregarPiezas(string[,] tableroM)
    {
        // Solicitar al usuario que ingrese la cantidad de piezas
        Console.WriteLine("Ingrese la cantidad de piezas: ");
        CantidadPiezas = Convert.ToInt32(Console.ReadLine());

        // Instanciar un objeto de la clase Tablero
        Tablero tablero = new Tablero();

        // Ciclo para agregar la cantidad de piezas ingresadas
        for (int i = 0; i < CantidadPiezas; i++)
        {
            // Solicitar al usuario que ingrese el tipo de pieza
            Console.WriteLine("Ingrese el tipo de pieza: ");
            Console.WriteLine("1) Caballo");
            Console.WriteLine("2) Alfil");
            Console.WriteLine("3) Peón");
            Console.WriteLine("4) Torre");
            Console.WriteLine("5) Rey");
            TipoPieza = Convert.ToInt32(Console.ReadLine());

            string nombrePieza = "";

            // Determinar el nombre de la pieza según la selección del usuario
            switch (TipoPieza)
            {
                case 1:
                    Console.WriteLine("La pieza es caballo");
                    nombrePieza = "Caballo";
                    break;
                case 2:
                    Console.WriteLine("La pieza es alfil");
                    nombrePieza = "Alfil";
                    break;
                case 3:
                    Console.WriteLine("La pieza es peón");
                    nombrePieza = "Peón";
                    break;
                case 4:
                    Console.WriteLine("La pieza es torre");
                    nombrePieza = "Torre";
                    break;
                case 5:
                    Console.WriteLine("La pieza es rey");
                    nombrePieza = "Rey";
                    break;
                default:
                    Console.WriteLine("No es válido");
                    break;
            }

            // Solicitar al usuario que ingrese el color de la pieza
            Console.WriteLine("Ingrese el color de la pieza: ");
            Console.WriteLine("1) Blanca");
            Console.WriteLine("2) Negra");
            ColorPieza = Convert.ToInt32(Console.ReadLine());

            string colorPieza = "";

            // Determinar el color de la pieza según la selección del usuario
            switch (ColorPieza)
            {
                case 1:
                    Console.WriteLine("La pieza es blanca");
                    colorPieza = "Blanco";
                    break;
                case 2:
                    Console.WriteLine("La pieza es negra");
                    colorPieza = "Negro";
                    break;
                default:
                    Console.WriteLine("No es válido");
                    break;
            }

            // Solicitar al usuario que ingrese la columna de la pieza
            Console.WriteLine("Ingrese la columna: ");
            string columna = Console.ReadLine();

            int cols = 0;
            switch (columna)
            {
                case "a":
                    cols = 0;
                    break;
                case "b":
                    cols = 1;
                    break;
                case "c":
                    cols = 2;
                    break;
                case "d":
                    cols = 3;
                    break;
                case "e":
                    cols = 4;
                    break;
                case "f":
                    cols = 5;
                    break;
                case "g":
                    cols = 6;
                    break;
                case "h":
                    cols = 7;
                    break;
                default:
                    Console.WriteLine("No existe en el tablero");
                    break;
            }
            Console.WriteLine("Se agregó la columna");

            // Solicitar al usuario que ingrese la fila de la pieza
            Console.WriteLine("Ingrese la fila: ");
            int fila = Convert.ToInt32(Console.ReadLine());

            // Verificar si la fila ingresada es válida
            if (fila >= 1 && fila <= 8)
            {
                Console.WriteLine("Se agregó la fila");
            }
            else
            {
                Console.WriteLine("No es válido");
            }

            // Verificar si la posición en el tablero está vacía y agregar la pieza
            if (tableroM[cols, fila] == null)
            {
                tableroM[cols, fila] = nombrePieza + colorPieza;
                Console.WriteLine(tableroM[cols, fila]);
                Console.WriteLine("Se agregó la pieza al tablero");
            }
            else
            {
                Console.WriteLine("La posición está ocupada");
            }
        }
        return ""; 
    }
}
