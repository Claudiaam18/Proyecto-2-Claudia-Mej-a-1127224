﻿namespace Proyecto_2__Claudia_Mejía_1127224;

public class Tablero
{
    // Variables miembro de la clase
    public string ImprimirLetras = ""; // Variable para imprimir letras
    public string Imprimir2 = ""; // Variable auxiliar
    public int fila = 0; // Variable para almacenar la fila actual
    public int columna = 0; // Variable para almacenar la columna actual
    public string colorDama = ""; // Variable para almacenar el color de la dama
    public string[,] TableroPiezas = new string[8,8]; // Matriz para representar el tablero de piezas

    // Método para validar las posiciones de la dama en el tablero
    public void ValidarPosiciones(string[,] tableroM)
    {
        for(int x = 0; x<8;x++)
        {
            for(int y=0; y<8;y++)
            {
               TableroPiezas[x,y]= tableroM[x,y];
            }
        }
        // Crear una instancia de la clase Dama
        Dama Objposdama = new Dama();
        // Obtener la posición actual de la dama
        int[] Arrposdama = Objposdama.DevolverPosDama();
        int columnaDama = Arrposdama[0] - 1; // Columna de la dama (ajustada a índice base 0)
        int filaDamaInicio = Arrposdama[1] - 1; // Fila de la dama (ajustada a índice base 0)
        colorDama = Objposdama.DevolverColorDama(); // Obtener el color de la dama
        // Imprimir la posición actual de la dama
        Console.WriteLine("La Dama se encuentra en la posición: " + (char)('a' + columnaDama +1) + "," + (filaDamaInicio + 1));

        Console.WriteLine("Validaciones hacia arriba"); //validar posiciones arriba
        for (int filaDamaActual = filaDamaInicio + 1; filaDamaActual < 8; filaDamaActual++)
        {
            if (TableroPiezas[filaDamaActual, columnaDama] == null)
            {
                Console.WriteLine("Vacío en posición: " + (char)('a' + columnaDama +1) + "," + (filaDamaActual + 1));
            }
            else
            {
                string pieza = TableroPiezas[filaDamaActual, columnaDama];
                string colorPiezaActual = pieza;

                if (colorDama == colorPiezaActual)
                {
                    Console.WriteLine("La posición está ocupada por: " + pieza + " en " + (char)('a' + columnaDama) + "," + (filaDamaActual + 1));
                }
                else
                {
                    Console.WriteLine("Vacío en posición: " + (char)('a' + columnaDama) + "," + (filaDamaActual + 1));
                }
                for(int x = 0; x<8;x++)
        {
            for(int y=0; y<8;y++)
            {
               TableroPiezas[x,y]= tableroM[x,y];
            }
        }
            }
        }
        
        Console.WriteLine("Validaciones hacia abajo"); //validar posiciones abajo
        for (int filaDamaActual = filaDamaInicio - 1; filaDamaActual >= 0; filaDamaActual--)
        {
            if (tableroM[filaDamaActual, columnaDama] == null)
            {
                Console.WriteLine("Vacío en posición: " + (char)('a' + columnaDama+1) + "," + (filaDamaActual + 1));
            }
            else
            {
                string pieza = tableroM[filaDamaActual, columnaDama];
                string colorPiezaActual = pieza.Contains("Negro") ? "Negro" : "Blanco";

                if (colorDama == colorPiezaActual)
                {
                    Console.WriteLine("La posición está ocupada por: " + pieza + " en " + (char)('a' + columnaDama) + "," + (filaDamaActual + 1));
                }
                else
                {
                    Console.WriteLine("Vacío en posición: " + (char)('a' + columnaDama) + "," + (filaDamaActual + 1));
                }
            }
        }

        Console.WriteLine("Validaciones hacia la derecha"); //validar posiciones derecha
        for (int columnaDamaActual = columnaDama + 1; columnaDamaActual < 7; columnaDamaActual++)
        {
            if (tableroM[filaDamaInicio, columnaDamaActual] == null)
            {
                Console.WriteLine("Vacío en posición: " + (char)('a' + columnaDamaActual+1) + "," + (filaDamaInicio + 1));
            }
            else
            {
                string pieza = tableroM[filaDamaInicio, columnaDamaActual];
                string colorPiezaActual = pieza.Contains("Negro") ? "Negro" : "Blanco";

                if (colorDama == colorPiezaActual)
                {
                    Console.WriteLine("La posición está ocupada por: " + pieza + " en " + (char)('a' + columnaDamaActual) + "," + (filaDamaInicio + 1));
                }
                else
                {
                    Console.WriteLine("Vacío en posición: " + (char)('a' + columnaDamaActual) + "," + (filaDamaInicio + 1));
                }
            }
        }

        Console.WriteLine("Validaciones hacia la izquierda"); //validar posiciones izquierda
        for (int columnaDamaActual = columnaDama - 1; columnaDamaActual >= 0; columnaDamaActual--)
        {
            if (tableroM[filaDamaInicio, columnaDamaActual] == null)
            {
                Console.WriteLine("Vacío en posición: " + (char)('a' + columnaDamaActual+1) + "," + (filaDamaInicio + 1));
            }
            else
            {
                string pieza = tableroM[filaDamaInicio, columnaDamaActual];
                string colorPiezaActual = pieza.Contains("Negro") ? "Negro" : "Blanco";

                if (colorDama == colorPiezaActual)
                {
                    Console.WriteLine("La posición está ocupada por: " + pieza + " en " + (char)('a' + columnaDamaActual) + "," + (filaDamaInicio + 1));
                }
                else
                {
                    Console.WriteLine("Vacío en posición: " + (char)('a' + columnaDamaActual + 1) + "," + (filaDamaInicio + 1));
                }
            }
        }

        Console.WriteLine("Validaciones hacia la diagonal derecha arriba"); //validar posiciones diagonal derecha arriba
        int i = filaDamaInicio + 1;
        int j = columnaDama + 1;

        while (i < 8 && j < 8)
        {
            if (tableroM[i, j] == null)
            {
                Console.WriteLine("Vacío en posición: " + (char)('a' + j+1) + "," + (i + 1));
            }
            else
            {
                string pieza = tableroM[i, j];
                string colorPiezaActual = pieza.Contains("Negro") ? "Negro" : "Blanco";

                if (colorDama == colorPiezaActual)
                {
                    Console.WriteLine("La posición está ocupada por: " + pieza + " en " + (char)('a' + j) + "," + (i + 1));
                }
                else
                {
                    Console.WriteLine("Vacío en posición: " + (char)('a' + j) + "," + (i + 1));
                }
            }
            
            i++;
            j++;
        }

        Console.WriteLine("Validaciones hacia la diagonal izquierda arriba"); //validar posiciones diagonal izquierda arriba
        i = filaDamaInicio + 1;
        j = columnaDama - 1;

        while (i < 8 && j >= 0)
        {
            if (tableroM[i, j] == null)
            {
                Console.WriteLine("Vacío en posición: " + (char)('a' + j+1) + "," + (i + 1));
            }
            else
            {
                string pieza = tableroM[i, j];
                string colorPiezaActual = pieza;

                if (colorDama == colorPiezaActual)
                {
                    Console.WriteLine("La posición está ocupada por: " + pieza + " en " + (char)('a' + j) + "," + (i + 1));
                }
                else
                {
                    Console.WriteLine("Vacío en posición: " + (char)('a' + j) + "," + (i + 1));
                }
            }
            
            i++;
            j--;
        }

        Console.WriteLine("Validaciones hacia la diagonal derecha abajo"); //validar posiciones diagonal derecha abajo
        i = filaDamaInicio - 1;
        j = columnaDama + 1;

        while (i >= 0 && j < 8)
        {
            if (tableroM[i, j] == null)
            {
                Console.WriteLine("Vacío en posición: " + (char)('a' + filaDamaInicio+1) + "," + (i + 1));
            }
            else
            {
                string pieza = tableroM[i, j];
                string colorPiezaActual = pieza.Contains("Negro") ? "Negro" : "Blanco";

                if (colorDama == colorPiezaActual)
                {
                    Console.WriteLine("La posición está ocupada por: " + pieza + " en " + (char)('a' + j) + "," + (i + 1));
                }
                else
                {
                    Console.WriteLine("Vacío en posición: " + (char)('a' + filaDamaInicio) + "," + (i + 1));
                }
            }
            
            i--;
            j++;
        }

        Console.WriteLine("Validaciones hacia la diagonal izquierda abajo"); //validar posiciones diagonal izquierda abajo
        i = filaDamaInicio - 1;
        j = columnaDama - 1;

        while (i >= 0 && j >= 0)
        {
            if (tableroM[i, j] == null)
            {
                Console.WriteLine("Vacío en posición: " + (char)('a' + filaDamaInicio+1) + "," + (i + 1));
            }
            else
            {
                string pieza = tableroM[i, j];
                string colorPiezaActual = pieza.Contains("Negro") ? "Negro" : "Blanco";

                if (colorDama == colorPiezaActual)
                {
                    Console.WriteLine("La posición está ocupada por: " + pieza + " en " + (char)('a' + j) + "," + (i + 1));
                }
                else
                {
                    Console.WriteLine("Vacío en posición: " + (char)('a' + j) + "," + (i + 1));
                }
            }
            
            i--;
            j--;
        }


    }
    
   public void ImprimirTablero(string[,] tableroM)
{
    // Imprimir encabezado de columnas
    Console.Write("   ");
    for (int columna = 0; columna < 8; columna++)
    {
        Console.Write(" " + (char)('a' + columna) + " ");
    }
    Console.WriteLine();

    // Imprimir filas de arriba hacia abajo
    for (int fila = 7; fila >= 0; fila--)
    {
        // Imprimir etiqueta de fila
        Console.Write((fila + 1) + "  ");
        for (int columna = 0; columna < 8; columna++)
        {
            string pieza = tableroM[columna, fila]; 
            if (pieza == null)
            {
                Console.Write(" . "); // Representa una casilla vacía
            }
            else
            {
                Console.Write(" " + pieza[0] + " "); // Imprime la primera letra de la pieza para simplificación
            }
        }
        Console.WriteLine();
    }
}


}