﻿namespace Proyecto_2__Claudia_Mejía_1127224;

public class Dama
{
    public int ColorDama; // Almacena el color de la dama
    public string PosicionDama = ""; // Almacena la posición de la dama
    static int cols = 0; // Columna de la dama
    static int fila = 0; // Fila de la dama
    static string colorPieza = ""; // Color de la dama

    // Método para agregar una dama al tablero
    public string AgregarDama(string[,] tableroM)
    {
        // Solicitar al usuario que ingrese el color de la dama
        Console.WriteLine("Ingrese el color de la dama: ");
        Console.WriteLine("1) Blanca");
        Console.WriteLine("2) Negra");
        ColorDama = Convert.ToInt32(Console.ReadLine());

        // Determinar el color de la dama según la selección del usuario
        switch(ColorDama)
        {
            case 1:
                Console.WriteLine("La dama es blanca");
                colorPieza = "Blanco";
                break;
            case 2:
                Console.WriteLine("La dama es negra");
                colorPieza = "Negro";
                break;
            default:
                Console.WriteLine("No es válido");
                break;
        }

        // Solicitar al usuario que ingrese la columna de la dama
        Console.WriteLine("Ingrese la columna: ");
        string columna = Console.ReadLine();

        // Asignar la columna según la entrada del usuario
        switch(columna)
        {
            case "a":
                cols = 0;
                break;
            case "b":
                cols = 1;
                break;  
            case "c":
                cols = 2;
                break; 
            case "d":
                cols = 3;
                break;
            case "e":
                cols = 4;
                break;
            case "f":
                cols = 5;
                break;
            case "g":
                cols = 6;
                break;
            case "h":
                cols = 7;
                break;
            default:
                Console.WriteLine("No existe en el tablero");
                break;    
        }
        Console.WriteLine("Se agregó la columna");

        // Solicitar al usuario que ingrese la fila de la dama
        Console.WriteLine("Ingrese la fila: ");
        fila = Convert.ToInt32(Console.ReadLine());

        // Verificar si la fila ingresada es válida
        if(fila >= 1 && fila <= 8)
        {
            Console.WriteLine("Se agregó la fila");
        }
        else
        {
            Console.WriteLine("No es válido");
        }

        // Verificar si la posición en el tablero está vacía y agregar la dama
        if(tableroM[cols, fila] == null)
        {
            tableroM[cols, fila] = "Dama" + colorPieza;
            Console.WriteLine(tableroM[cols -1 , fila]);
            Console.WriteLine("Se agregó la dama al tablero");
        }
        else
        {
            Console.WriteLine("La posición está ocupada");
        }

        return ""; 
    }

    // Método para devolver la posición de la dama
    public int[] DevolverPosDama()
    {
        int[] posDama = new int[2];
        posDama[0] = cols; // Columna de la dama
        posDama[1] = fila; // Fila de la dama
        return posDama; // Devolver la posición de la dama
    }

    // Método para devolver el color de la dama
    public string DevolverColorDama()
    {
        string colorDama = colorPieza; // Color de la dama
        return colorDama; // Devolver el color de la dama
    }
}