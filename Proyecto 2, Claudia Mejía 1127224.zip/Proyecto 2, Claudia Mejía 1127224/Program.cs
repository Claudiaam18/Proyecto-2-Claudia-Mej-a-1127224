﻿using Proyecto_2__Claudia_Mejía_1127224;
using System;

public class Program
{
    public static void Main()
    {
        // Crear instancias de las clases necesarias
        Pieza pieza = new Pieza();
        string [,] tableroM = new string[8,8];
        Dama dama = new Dama();
        Tablero tablero = new Tablero();

        int opcion = 0;
        do
        {
            // Mostrar menú de opciones
            Console.WriteLine("¿Qué desea realizar?: ");
            Console.WriteLine("1) Agregar pieza");
            Console.WriteLine("2) Agregar Dama");
            Console.WriteLine("3) Validar posiciones");
            Console.WriteLine("4) Imprimir tablero");
            Console.WriteLine("5) Salir");

            // Leer la opción seleccionada
            opcion = int.Parse(Console.ReadLine());

            // Ejecutar la opción seleccionada
            switch(opcion)
            {
                case 1:
                    // Agregar pieza al tablero
                    Console.WriteLine(pieza.AgregarPiezas(tableroM));
                    break;
                case 2:
                    // Agregar dama al tablero
                    Console.WriteLine(dama.AgregarDama(tableroM));
                    break;

                case 3:
                    // Validar las posiciones en el tablero
                    tablero.ValidarPosiciones(tableroM);
                    break;
                
                case 4:
                    // Imprimir el tablero con las piezas actuales
                   tablero.ImprimirTablero(tableroM);
                    break;
                
                case 5:
                    // Salir del programa
                    Console.WriteLine("Saliendo...");
                    break;
            }
        } while(opcion != 5);
    }
}
